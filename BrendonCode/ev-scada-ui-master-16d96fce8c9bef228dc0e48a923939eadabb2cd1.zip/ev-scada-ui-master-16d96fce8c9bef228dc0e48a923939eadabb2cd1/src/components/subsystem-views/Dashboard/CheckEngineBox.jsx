
import React, {Component} from 'react'


export default class CheckEngineBox extends Component {
  render() {
    let c = [];
    // this.props.items.forEach(function (e) {
    //
    // }.bind(this));
    return <br/>
    return <g>
      <rect x={this.props.x} y={this.props.y}
      width={this.props.width} height={this.props.height}
      stroke="white" strokeWidth="2">
      </rect>
      {c}
    </g>
  }
}


import React, {Component} from 'react'
var JSONViewer = require('react-json-viewer');
var todos ={
   };

export default class BatteryPack extends Component {

  render() {
    

    return <div>
      <JSONViewer json={todos}></JSONViewer>

      
    </div>
  }
}


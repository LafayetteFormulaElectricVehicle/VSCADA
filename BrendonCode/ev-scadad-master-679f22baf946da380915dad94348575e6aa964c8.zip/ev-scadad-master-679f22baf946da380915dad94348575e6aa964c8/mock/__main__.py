# Copyright 2016 Brendon Carroll

import sys
import asyncio
import signal

from scadad.networks import CANBus

from .pacman import PACMAN
from .motor_controller import MotorController

MOCK_TYPES = {
    'PACMAN': PACMAN,
    'MotorController': MotorController,
}

def main():
    mock_type = sys.argv[1]
    iface = sys.argv[2]
    address = [int(i, 16) for i in sys.argv[3:]]

    cb = CANBus(iface)

    try:
        MockClass = MOCK_TYPES[mock_type]
        model = MockClass(cb, address)

        loop = asyncio.get_event_loop()

        def stop(fut):
            fut.exception()
            loop.stop()

        def exit_func():
            print('stopping')
            tasks = []
            for task in asyncio.Task.all_tasks():
                task.cancel()
                tasks.append(task)
            fut = asyncio.gather(*tasks)
            fut.add_done_callback(stop)

        loop.add_signal_handler(
            signal.SIGINT,
            exit_func)
        loop.run_forever()

    except KeyError:
        print(mock_type, 'is not a known system type.')

if __name__ == '__main__':
    main()

# Copyright 2016 Brendon Carroll

import asyncio

class MotorController(object):

    def __init__(self, canbus, address):
        self.canbus = canbus
        self.address = address

        print('NOTE: Motor Controller has fixed addresses')

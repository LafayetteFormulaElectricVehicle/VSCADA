# Copyright 2016 Brendon Carroll

import asyncio
import struct
import random
import time

from scadad.networks import CANBus

NUM_CELLS = 7

class PACMAN(object):

    def __init__(self, canbus, address):
        self.canbus = canbus
        self.address = address

        self.cells = []
        for i in range(NUM_CELLS):
            cell = (i, 0, 9.5, 26.0)
            self.cells.append((i, 0, 9.5, 26.0))

        self.mode = 0
        self.starttime = time.time()

        asyncio.ensure_future(self.mutate())
        asyncio.ensure_future(self.loop())

    async def mutate(self):
        while True:
            for i, cell in enumerate(self.cells):
                voltage = random.randint(0, (2<<15)-1)
                temp = random.randint(0, (2<<15)-1)
                self.cells[i] = (i, 0, voltage, temp)
            await asyncio.sleep(0.2)

    async def loop(self):
        while True:
            # Address 1
            status = 0
            pack_voltage = sum(map(lambda x: x[3], self.cells)) % (2 ** 15 -1)
            current = random.randint(0, 2 ** 31 - 1)
            soc = 50 // 100 * 255
            data = struct.pack('>BHiB', status, pack_voltage, current, soc)
            await self.canbus.send(self.address[0], data)

            # Address 2
            system_uptime = round((time.time() - self.starttime) * 100);
            coulombs = random.randint(0, (1<<14) - 1)
            data = struct.pack('>Ii', system_uptime, coulombs)
            await self.canbus.send(self.address[1], data)

            # Broadcast cells
            for cell in self.cells:
                data = struct.pack('>BBHH', *cell)
                await self.canbus.send(self.address[2], data)

            await asyncio.sleep(0.200)

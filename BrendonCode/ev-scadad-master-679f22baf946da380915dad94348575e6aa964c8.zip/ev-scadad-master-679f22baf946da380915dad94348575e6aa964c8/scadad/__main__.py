import asyncio
import signal

import yaml

from scadad.system import System
from scadad.web_api import WebAPI
from scadad.eventstream_logger import EventStreamLogger

ST_FILENAME = 'system_topology.yml'

def main():
    # Setup system
    with open(ST_FILENAME) as f:
        top = yaml.load(f)
    s = System(top)
    print(s)

    # Setup web interface
    wa = WebAPI(s)

    # Setup signal handlers
    loop = asyncio.get_event_loop()

    def finish_cleanup(fut):
        fut.exception()
        loop.stop()

    for signame in ('SIGINT', 'SIGTERM'):
        def start_cleanup():
            print('Got {} exiting'.format(signame))
            all_tasks = asyncio.Task.all_tasks()
            for task in all_tasks:
                task.cancel()
            fut_all = asyncio.gather(*all_tasks)
            fut_all.add_done_callback(finish_cleanup)
        loop.add_signal_handler(
            getattr(signal, signame),
            start_cleanup
        )

    loop.set_debug(True)

    dl = EventStreamLogger(s)

    # Start event loop
    try:
        loop.run_forever()
    finally:
        loop.close()

if __name__ == '__main__':
    main()

# Copyright 2016 Brendon Carroll

import asyncio
import socket
import struct
import time
import collections

from scadad.util.dispatcher import Dispatcher

#These addresses will be automatically filtered out and not processed
BAD_ADDRESSES = [0x250, 0x251, 0x252,]

can_frame_fmt = "=IB3x8s"
can_frame_size = struct.calcsize(can_frame_fmt)

CANMessage = collections.namedtuple('CANMessage',
['addr', 'is_request', 'data', 'timestamp'])

def build_can_frame(can_id, data):
    can_dlc = len(data)
    data = data.rjust(can_dlc, b'\x00')
    return struct.pack(can_frame_fmt, can_id, can_dlc, data)

def dissect_can_frame(frame):
    can_id, can_dlc, data = struct.unpack(can_frame_fmt, frame)
    return (can_id, can_dlc, data[:can_dlc])

class Router(object):

    def __init__(self):
        self.single_routes = {}
        self.ranges = {}
        self.default = None

    def on_route(self, addr, callback):
        if addr in self.single_routes:
            self.single_routes[addr].append(callback)
        else:
            self.single_routes[addr] = [callback]

    def on_range(self, r, callback):
        if addr in self.ranges:
            self.ranges[addr].append(callback)
        else:
            self.ranges[addr] = [callback]

    def set_default(self, callback):
        self.default = q
        return q

    async def handle(self, key, msg):
        handled = False
        # Check if there is a single route
        if key in self.single_routes:
            for cb in self.single_routes[key]:
                await cb(msg)
            handled = True

        # Check if it is in a range
        for r, q in self.ranges:
            if (r[0] <= key) and (key <= r[1]):
                for cb in self.ranges[key]:
                    await cb(msg)
                handled = True
        return handled

        # Check the default
        if handled and self.default is not None:
            await self.default.put(msg)

class CANBus(object):

    def __init__(self, interface):
        self.active = True
        self.interface = interface

        # Setup routing
        self.router = Router()

        # Setup socket
        self.socket = socket.socket(socket.AF_CAN,
            socket.SOCK_RAW, socket.CAN_RAW)
        self.socket.bind((interface,))
        self.socket.setblocking(False)

        self.on_route = self.router.on_route
        self.on_range = self.router.on_range
        self.set_default = self.router.set_default

        # Setup event loop
        self.loop = asyncio.get_event_loop()
        self.loop.create_task(self.read_loop())


    async def read_loop(self):
        while self.active:
            frame = await self.loop.sock_recv(self.socket, can_frame_size)
            timestamp = time.time()
            (can_id, can_dlc, data) = dissect_can_frame(frame)
            addr = can_id & 0xFFFFFFF
            is_request =  (can_id & ~0xFFFFFFF) > 0
            if(addr not in BAD_ADDRESSES):
               msg = CANMessage(addr, is_request, data, timestamp)
               await self.router.handle(msg.addr, msg)

    async def send(self, addr, data):
        frame = build_can_frame(addr, data)
        await self.loop.sock_sendall(self.socket, frame)

    async def request(self, addr):
        can_id = 0x40000000 | addr
        frame = build_can_frame(can_id, bytes())
        await self.loop.sock_sendall(self.socket, frame)

    def __repr__(self):
        return "<CAN: {}>".format(self.interface)

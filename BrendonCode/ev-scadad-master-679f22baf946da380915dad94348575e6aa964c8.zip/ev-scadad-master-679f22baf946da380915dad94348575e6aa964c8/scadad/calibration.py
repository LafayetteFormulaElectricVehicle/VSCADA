import yaml

CALIBRATION_FILENAME = 'calibration.yml'

with open(ST_FILENAME) as f:
    parameters = yaml.load(f)

def __get__(key):
    return parameters

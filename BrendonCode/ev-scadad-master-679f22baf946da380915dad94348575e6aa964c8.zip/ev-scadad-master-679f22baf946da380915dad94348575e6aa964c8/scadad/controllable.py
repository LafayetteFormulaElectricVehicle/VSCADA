# Copyright 2016 Brendon Carroll and Domenick Falco

import time

class Controllable(object):

    #possibilities only used for pull down menus
    def __init__(self, value, possibilities=None, maxv=None, minv=None, step=1):
        self.actual = value
        self.input = value
        self.possibilities = possibilities
        self.in_sync = True
        self.max = maxv
        self.min = minv
        self.step = step
        self.timestamp = time.time()

    def set_actual(self, new_actual, timestamp=time.time()):
        self.actual = new_actual
        self.in_sync = (self.input == self.actual)
        self.timestamp = time.time()
        return self.in_sync

    def set_actual_and_input(self, new_value, timestamp=time.time()):
        self.set_actual(new_value)
        self.set_input(new_value)

    def toDict(self):
        d = {
            'type': 'controllable',
            'input': self.input,
            'actual': self.actual,
            'possibilities': self.possibilities,
            'step': self.step,
            'max': self.max,
            'min': self.min,
            'location': self.location,
            'timestamp': self.timestamp,
        }
        return d

    def set_input(self, new_input, timestamp=time.time()):
        # Only update if type is correct
        if type(new_input) == type(self.input):
            if(type(new_input) != str):
                # Make sure it is in range.  It is the users responsibility
                # to make sure the max and min values make sense if they ar
                # assigned.
                if self.max != None and new_input > self.max:
                    return
                if self.min != None and new_input < self.min:
                    return

            change = (self.input != new_input)
            self.input = new_input
            self.in_sync = (self.input == self.actual)
            self.timestamp = time.time()
            return change

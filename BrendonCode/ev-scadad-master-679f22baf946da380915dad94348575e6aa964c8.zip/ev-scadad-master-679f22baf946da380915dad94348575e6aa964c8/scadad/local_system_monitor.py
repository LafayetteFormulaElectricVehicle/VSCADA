# Copyright 2016 Domenick Falco

import asyncio
import psutil

from scadad.measurand import Measurand
from sys import argv

class LocalSystemMonitor(object):

    def __init__(self):
        # Setup model
        self.measurands = {}
        self.measurands['cpu_percent'] = Measurand('%')
        self.measurands['cpu_temperature'] = Measurand('Celcius')

        self.measurands['memory_percentange used'] = Measurand('%')
        self.measurands['total_memory'] = Measurand('Bytes')
        self.measurands['used_memory'] = Measurand('Bytes')

        self.measurands['ip_address'] = Measurand('address')

        self.loop = asyncio.get_event_loop()
        self.loop.create_task(self.checkStats())


    async def checkStats(self):
        while True:
            mem = psutil.virtual_memory()

            #Try to figure our IP
            try:
                ip_address = psutil.net_if_addrs()['enp5s0'][0][1]
            except KeyError:
                try:
                    ip_address = psutil.net_if_addrs()['eth0'][0][1]
                except KeyError:
                    ip_address = 'Unable to find Address'

            #Try to get CPU temperature (only on newer kernals)
            cpu_temperature = ''
            try:
                txt = open('/sys/class/thermal/thermal_zone0/temp')
                cpu_temperature = int(txt.read()[:-1]) /1000
            except OSError:
                cpu_temperature = 'Unable to read temperature (Are you not using RaspPi?)'


            d = {
                'cpu_percent': psutil.cpu_percent(),
                'cpu_temperature': cpu_temperature,

                'memory_percentange used': mem[2],
                'total_memory': mem[1],
                'used_memory': mem[3],

                'ip_address': ip_address

            }
            change = False
            for k, v in d.items():
                m = self.measurands[k]
                c = m.update(v)
                change = change or c

            await asyncio.sleep(1)

    def toDict(self):
        d = {}
        for k, m in self.measurands.items():
            d[k] = m.toDict()

        return d

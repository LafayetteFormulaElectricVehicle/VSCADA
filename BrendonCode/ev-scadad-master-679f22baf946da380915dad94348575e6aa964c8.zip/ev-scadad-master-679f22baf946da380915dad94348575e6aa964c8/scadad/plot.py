# Copyright 2016 Brendon Carroll

import collections
import time
import asyncio
import scadad.message_bus


mb = scadad.message_bus.getbus()


class Plot(object):

    def __init__(self, location,  data_watching, broadcast_per=1, output_points=30):

        self.location = location
        self.broadcast_per = broadcast_per
        self.data_watching = data_watching

        self.current_time = 0
        self.input = True
        self.actual = True

        #throw zeros in for all recorded data
        self.most_recent_data = []
        self.data_sets = []
        for d in range(len(self.data_watching)):
            self.most_recent_data.append(0)
            self.data_sets.append([])
            for i in range(output_points):
                self.data_sets[d].append(0)

        self.time_axis = []
        for i in range(output_points):
            self.time_axis.append(0)

        self.timestamp = time.time()

        asyncio.ensure_future(self.broadcast())
        asyncio.ensure_future(self.read_bus())

    async def read_bus(self):
        async for msg in mb:
            for i in range(len(self.data_watching)):
                dataType = self.data_watching[i]
                if(len(dataType) == 2):
                    if msg['location'][0] == dataType[0]:
                        if msg['location'][1] == dataType[1]:
                             self.most_recent_data[i] = msg['calibrated']
                elif(len(dataType) == 4):
                    if msg['location'][0] == dataType[0]:
                        if msg['location'][1] == dataType[1]:
                            if msg['location'][2] == dataType[2]:
                                if msg['location'][3] == dataType[3]:
                                     self.most_recent_data[i] = msg['calibrated']
                else:
                    print('invalid location detectected')

    async def broadcast(self):
        while True:
            if self.input == True:
                for d in range(len(self.data_watching)):
                    self.data_sets[d].append(self.most_recent_data[d])
                    self.data_sets[d].pop(0)
                self.current_time = self.current_time + self.broadcast_per
                self.time_axis.append(self.current_time)
                self.time_axis.pop(0)

            await mb.dispatch(self.toDict())
            await asyncio.sleep(self.broadcast_per)

    # def play_pause_graph(self, new_active, timestamp=time.time()):
    #     change = (self.active != new_active)
    #     self.active = new_active
    #     self.timestamp = time.time()
    #     return change

    def set_input(self, new_input, timestamp=time.time()):
        print(self)
        # Only update if type is correct
        if type(new_input) == type(self.input):
            if(type(new_input) != str):
                # Make sure it is in range.  It is the users responsibility
                # to make sure the max and min values make sense if they ar
                # assigned.
                if self.max != None and new_input > self.max:
                    return
                if self.min != None and new_input < self.min:
                    return

            change = (self.input != new_input)
            self.input = new_input
            self.in_sync = (self.input == self.actual)
            self.timestamp = time.time()
            return change

    def set_actual(self, new_actual, timestamp=time.time()):
        self.actual = new_actual
        self.in_sync = (self.input == self.actual)
        self.timestamp = time.time()
        return self.in_sync

    def toDict(self):
        d = {
            'type': 'plot',
            'data_watching': self.data_watching,
            'data_sets': self.data_sets,
            'time_axis' : self.time_axis,
            'location': self.location,
            'timestamp': self.timestamp,
            'input': self.input,
            'actual': self.actual,
        }
        return d

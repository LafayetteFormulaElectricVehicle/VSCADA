# Copyright 2016 Brendon Carroll

import asyncio

class Watchdog(object):
    '''A simple watchdog timer for use with asyncio.
    '''

    def __init__(self, period, callback):
        self.period = period
        self.callback = callback
        self.task = asyncio.ensure_future(self.expire())

    async def expire(self):
        try:
            await asyncio.sleep(self.period)
            print('Watchdog expired.')
            self.callback()
        except asyncio.CancelledError:
            pass

    def reset(self):
        '''Resets the timer.'''
        self.task.cancel()
        self.task = asyncio.ensure_future(self.expire())

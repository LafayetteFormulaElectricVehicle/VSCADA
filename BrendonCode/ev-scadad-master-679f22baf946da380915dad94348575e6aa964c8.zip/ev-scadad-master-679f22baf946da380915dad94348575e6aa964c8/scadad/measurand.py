import collections
import time

import scadad.message_bus
mb = scadad.message_bus.getbus()

class Measurand(object):

    def __init__(self, unit, calibration_func=None, location=None):
        """A value to be measured. with units.
        """
        self.unit = unit
        self.calibration_func = calibration_func
        self.history = collections.deque()
        self.current_value = ('no-data', 'no-data')
        self.timestamp = None
        self.location = location

    def update(self, new_value, timestamp=time.time()):
        # new_value is a tuple (uncal, cal)
        new_value = (new_value, self.calibrate(new_value))
        # add it to the history
        self.history.append(new_value)
        self.timestamp = timestamp

        change = False

        if self.current_value[0] == 'no-data':
            self.current_value = new_value
            change = True
        elif new_value[0] != self.current_value[0]:
            self.current_value = new_value
            change = True
        else:
            self.current_value = new_value
            change = False
        return change

    def calibrate(self, value):
        if self.calibration_func is not None:
            return self.calibration_func(value)
        else:
            return value

    def toDict(self):
        d = {
            'type': 'measurand',
            'uncalibrated': self.current_value[0],
            'calibrated': self.current_value[1],
            'unit': self.unit,
            'location': self.location,
            'timestamp': self.timestamp
        }
        return d

    def __repr__(self):
        return u'<{uc} -> {c}{unit} @ {timestamp} >'.format(
            uc=self.current_value[0],
            unit=self.unit,
            c=self.current_value[1],
            timestamp = self.timestamp
        )

if __name__ == '__main__':
    m = Measurand(u'\u2103', lambda x: x/1024*100)
    m.update(400)
    print(m)
    m.update(200)
    print(m)
    print(m.toDict())

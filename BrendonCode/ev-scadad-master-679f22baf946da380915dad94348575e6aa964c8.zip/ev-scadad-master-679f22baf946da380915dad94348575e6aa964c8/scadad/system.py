#import scadad.can_bus
import ast
import asyncio
from datetime import datetime

import scadad.subsystems as subsystems
import scadad.networks as networks
import scadad.config as config
from scadad.local_system_monitor import LocalSystemMonitor
import scadad.welcome as welcome

import scadad.message_bus
mb = scadad.message_bus.getbus()

class System(object):

    def __init__(self, topology):
        self.networks = {}
        self.subsystems = {}
        self.stats = LocalSystemMonitor()

        self.name = config.get('name')
        self.starttime = datetime.now()
        self.event_count = 0

        asyncio.ensure_future(self.event_counter())

        # Physical Systems
        for k,v in topology['physical'].items():
            # try:
            # If it is a dictionary then it is a network
            if type(v) == type({}):
                self.add_network(k, v)
            # Otherwise it is a subsystem
            else:
                self.add_subsystem(k, v)
            # except AttributeError:
            #     print("Cannot find module" + str(v))

        # Virtual Systems
        for vs in topology['virtual']:
            # try:
            VSClass = getattr(subsystems, vs[0])
            if len(vs) > 1:
                subsystem = VSClass(self, *vs[1:])
            else:
                subsystem = VSClass(self)
            self.subsystems[repr(subsystem)] = subsystem
            # except AttributeError:
            #     print("Cannot find module" + str(vs))



    def add_network(self, name, topology):
        if name[:3] == 'can' or name[:4] == 'vcan':
            network = networks.CANBus(name)
            self.networks[name] = network
        else:
            return
        for k, v in sorted(topology.items(), key=lambda x: x[0]):
            self.add_subsystem((network, k), v)
        self.networks[repr(network)] = network

    def add_subsystem(self, location, systype):
        if isinstance(location, tuple):
            network = location[0]
            address = ast.literal_eval(location[1])
            location = (network, address)
        # try:
        subsystem = getattr(subsystems, systype)(location)
        self.subsystems[repr(subsystem)] = subsystem
        # except AttributeError as e:
        #     print('Error in system.py:line 72 -> Could not add subsystem:', systype)


    async def event_counter(self):
        async for msg in mb:
            self.event_count += 1

    def toDict(self):
        subsystems = {}
        for k, v in self.subsystems.items():
            subsystems[k] = v.toDict()
        d = {
            'type': 'system',
            'name': self.name,
            'starttime': self.starttime.isoformat(),
            'subsystems': subsystems,
            'stats': self.stats.toDict(),
            'event_count': self.event_count,
            'welcome': welcome.get_msg(),
        }
        return d

    def __str__(self):
        return '<System>\n{} subsystems loaded.\n{}'.format(len(self.subsystems.keys()), list(self.subsystems.values()))

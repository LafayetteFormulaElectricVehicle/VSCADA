# Copyright 2016 Brendon Carroll
import os
import json

from aiohttp import web
import asyncio

import scadad.config as config
from scadad.message_bus import getbus
mb = getbus()

PORT = config.get('webapi_port')
HOST = config.get('webapi_host')

UI_DIRPATH = config.get('webui_path')

if not UI_DIRPATH:
    UI_DIRPATH = os.path.dirname(__file__)

REFRESH_PERIOD = 0.2

class WebAPI(object):

    def __init__(self, system):
        self.system = system
        self.app = web.Application()
        self.websockets = []

        self.app.router.add_route('GET', '/ws', self.wshandler)
        self.app.router.add_static('/', UI_DIRPATH)

        loop = asyncio.get_event_loop()
        loop.create_task(loop.create_server(self.app.make_handler(), HOST, PORT))
        loop.create_task(self.system_monitor())
        loop.create_task(self.polling_monitor())

    async def polling_monitor(self):
        while True:
            jsondump = json.dumps(self.system.toDict())
            self.broadcast(jsondump)
            await asyncio.sleep(REFRESH_PERIOD)

    def broadcast(self, data):
        for ws in self.websockets:
            ws.send_str(data)

    async def system_monitor(self):
        async for msg in mb:
            if msg['type'] == 'controllable':
                jsondump = json.dumps(msg)
                self.broadcast(jsondump)
            if msg['type'] == 'measurand':
                try:
                    if msg['force_update'] is True:
                        self.broadcast(jsondump)
                except KeyError:
                    pass


    async def wshandler(self, request):
        ws = web.WebSocketResponse()
        await ws.prepare(request)

        self.websockets.append(ws)
        print('Client connected.')

        jsondumps = json.dumps(self.system.toDict())
        ws.send_str(jsondumps)

        try:
            async for msg in ws:
                data = json.loads(msg.data)
                if data['type'] == 'controllable':
                    ss_name = data['location'][0]
                    ss = self.system.subsystems[ss_name]
                    ss.applyDict(data)
                    self.broadcast(json.dumps(self.system.toDict()))
                #print('WS MSG RECV:', msg)
        finally:
            self.websockets.remove(ws)
            print('Client disconnected')
        return ws

    async def test(self):
        pass

if __name__ == '__main__':
    w = WebAPI({})
    loop = asyncio.get_event_loop()
    loop.run_forever()

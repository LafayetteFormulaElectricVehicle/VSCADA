# Copyright 2016 Brendon Carroll and Domenick Falco

import asyncio
import struct

from .subsystem import Subsystem, make_safe_handler
from scadad.controllable import Controllable
from scadad.measurand import Measurand
from scadad.watchdog import Watchdog
import scadad.message_bus
mb = scadad.message_bus.getbus()

WATCHDOG_TIMEOUT = 2

THROTTLE_SELECT = [
    'Physical',
    'Software'
]

class TractiveSystemController(Subsystem):
    systype = 'TractiveSystemController'
    next_id = 0

    def __init__(self, location):
        super().__init__(location)
        self.network, self.address = location
        [self.addr1, self.addr2] = self.address

        self.task = None
        self.wt = Watchdog(WATCHDOG_TIMEOUT, self.set_offline)

        # Setup model
        self.measurands = {
            'physical_throttle': Measurand(''),
            'drive_button': Measurand(''),
            'AIR_voltage_present': Measurand(''),
            'mc_voltage_present': Measurand(''),
            'current': Measurand('Amperes', lambda x: x * 5 / (2**16)),
            'voltage': Measurand('Volts', lambda x: x * 5 / (2**16))
        }
        for k, v in self.measurands.items():
            v.location = [self.name, k]

        self.controllables = {
            'throttle_select': Controllable('Physical', ['Physical', 'Software']),
            'software_throttle': Controllable (0, maxv=255, minv=0),
            'throttle_enable': Controllable(False),
            'open_safety_loop': Controllable(False),
            'close_precharge_relay': Controllable(False),
        }
        for k, v in self.controllables.items():
            v.location = [self.name, k]

        self.network.on_route(self.addr1, self.handle_addr1)

    def parseStatus(self, status):
        c = self.controllables

        # If the drive mode button is being pressed.  It means the
        # TSC knows what's best and we need to change the input
        if (status & 0x80) > 0:
            c['throttle_enable'].set_actual_and_input( (status & 0x1) > 0)
            c['throttle_select'].set_actual_and_input( THROTTLE_SELECT[(status & 0x2) >> 1])
            c['open_safety_loop'].set_actual_and_input( (status & 0x4) > 0)
            c['close_precharge_relay'].set_actual_and_input((status & 0x8) > 0)

        # If !drive_mode_button_pressed.  The TSC is just telling us things
        # to be friendly, but we still know best
        else:
            c['throttle_enable'].set_actual( (status & 0x1) > 0)
            c['throttle_select'].set_actual( THROTTLE_SELECT[(status & 0x2) >> 1])
            c['open_safety_loop'].set_actual( (status & 0x4) > 0)
            c['close_precharge_relay'].set_actual((status & 0x8) > 0)

        m = self.measurands
        m['drive_button'].update( (status & 0x10) > 0)
        m['AIR_voltage_present'].update( (status & 0x20) > 0)
        m['mc_voltage_present'].update((status & 0x40) > 0)

    async def continuous_send(self):
        ts = self.controllables['throttle_select']
        while ts.input == 'Software':
            await self.send_addr2()
            await asyncio.sleep(0.1)


    async def update_controllables(self):
        in_sync = True
        for c in self.controllables.values():
            in_sync = in_sync and c.in_sync
            #print(c.location[-1], c.in_sync, c.input, c.actual)
        if not in_sync:
            if self.task is None or self.task.done():
                await self.send_addr2()
                self.task = asyncio.ensure_future(self.continuous_send())

    @make_safe_handler
    async def handle_addr1(self, msg):
        data = struct.unpack('>BBBHH', msg.data)
        self.parseStatus(data[0])
        self.controllables['software_throttle'].set_actual(data[2])

        # Update measurands
        for name, i in [('physical_throttle', 1 ),('current', 3), ('voltage', 4)]:
            m = self.measurands[name]
            if m.update(data[i], timestamp=msg.timestamp):
                await mb.dispatch(m.toDict())

        self.made_contact()
        await self.update_controllables()

    async def send_addr2(self):
        status = 0
        c = self.controllables
        if c['throttle_enable'].input:
            status += 1
        if c['throttle_select'].input == 'Software':
            status += 2
        if c['open_safety_loop'].input:
            status += 4
        if c['close_precharge_relay'].input:
            status += 8
        soft_throt = self.controllables['software_throttle'].input
        data = struct.pack('>BB', status, soft_throt)
        await self.network.send(self.addr2, data)

    def applyDict(self, d):
        if d['type'] == 'controllable':
            name = d['location'][-1]
            if name in self.controllables:
                c = self.controllables[name]
                if c.set_input(d['input']):
                    asyncio.ensure_future(mb.dispatch(c.toDict()))
                asyncio.ensure_future(self.update_controllables())

    def toDict(self):
        d = super().toDict()
        for k, v in self.controllables.items():
            d[k] = v.toDict()
        for k, v in self.measurands.items():
            d[k] = v.toDict()
        return d

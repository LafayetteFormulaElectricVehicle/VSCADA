# Copyright 2016 Brendon Carroll and Domenick Falco

import asyncio
import math
import time

from .subsystem import Subsystem
import scadad.message_bus

mb = scadad.message_bus.getbus()

GEAR_RATIO = 2.5
WHEEL_RADIUS = 0.000142045 # In miles
RPM2SPEED = 2 * math.pi * WHEEL_RADIUS * 60 / GEAR_RATIO

class Dashboard(Subsystem):

    systype = 'Dashboard'
    next_id = 0

    def __init__(self, system, *args):
        super().__init__('virtual')

        # Get a MotorController from the system
        mcs = list(filter(lambda x: x.systype == 'MotorController',
            system.subsystems.values()))

        # Get a TSC from the system
        tsc = list(filter(lambda x: x.systype == 'TractiveSystemController',
            system.subsystems.values()))

        # Get a DC from the system
        dc = list(filter(lambda x: x.systype == 'DynomometerController',
            system.subsystems.values()))

        # Get a BatteryPack from the system
        bp = list(filter(lambda x: x.systype == 'BatteryPack',
            system.subsystems.values()))



        self.mc = mcs[0]
        self.tsc = tsc[0]
        self.dc = dc[0]
        self.bp = bp[0]

        self.controllables = self.tsc.controllables
        self.controllables['valve_position'] = self.dc.valve_position

        self.speed = 0
        self.current = 0
        self.motor_temperature = 0
        self.fuel = 0
        self.message = ''
        self.gear = 'P'

        if len(args) > 0 and args[0] == "demo":
            asyncio.ensure_future(self.demo_data())
        else:
            asyncio.ensure_future(self.read_bus())

    async def demo_data(self):
        while True:
            rpm = 4400/2 * math.sin(time.time()) + 4400/2
            self.speed = RPM2SPEED * rpm
            self.current = math.sqrt(rpm) * 10
            self.motor_temperature = rpm * 60/3000
            self.fuel = 0.5*math.sin(time.time()) + 0.5
            self.gear = 'D'
            self.message = 'Two Jedi have landed in the main hanger bay.'
            await mb.dispatch(self.toDict())
            await asyncio.sleep(0.05)

    async def read_bus(self):
         async for msg in mb:
             if msg['type'] == 'MotorController':
                 self.speed= msg['motor_rpm'].calibrated * RPM2SPEED
                 self.current = msg['rms_current'].calibrated
                 self.motor_temperature = msg['motor_temperature'].calibrated
                 await mb.dispatch(self.toDict())
             if msg['type'] == 'BatteryPack':
                self.fuel = msg['state_of_charge'].calibrated
                await mb.dispatch(self.toDict())

    async def send_addr2(self):
        status = 0
        c = self.controllables
        if c['throttle_enable'].input:
            status += 1
        if c['throttle_select'].input == 'Software':
            status += 2
        if c['open_safety_loop'].input:
            status += 4
        if c['close_precharge_relay'].input:
            status += 8
        soft_throt = self.controllables['software_throttle'].input
        data = struct.pack('>BB', status, soft_throt)
        await self.network.send(self.addr2, data)

    def applyDict(self, d):
        if d['type'] == 'controllable':
            name = d['location'][-1]
            if name in self.controllables:
                c = self.controllables[name]
                if c.set_input(d['input']):
                    asyncio.ensure_future(mb.dispatch(c.toDict()))
                asyncio.ensure_future(self.update_controllables())

    async def update_controllables(self):
        in_sync = True
        for c in self.controllables.values():
            in_sync = in_sync and c.in_sync
            #print(c.location[-1], c.in_sync, c.input, c.actual)


    def toDict(self):
        d = super().toDict()
        d['is_virtual'] = True
        d['speed'] = self.speed
        d['current'] = self.current
        d['motor_temperature'] = self.motor_temperature
        d['force_update'] = True
        d['fuel'] = self.fuel
        d['message'] = self.message
        d['gear'] = self.gear

        for k, v in self.controllables.items():
            d[k] = v.toDict()

        return d

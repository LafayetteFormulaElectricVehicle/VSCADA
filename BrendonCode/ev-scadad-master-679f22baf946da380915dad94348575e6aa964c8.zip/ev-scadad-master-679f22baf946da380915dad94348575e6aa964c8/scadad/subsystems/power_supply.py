# Inspired by 2015 VSCADA magnascpi
import serial
import asyncio

from .subsystem import Subsystem

GET_VOLT = 'MEAS:VOLT?\r\n'
GET_CURRENT = 'MEAS:CURR?\r\n'
GET_ONOFF = 'OUTP?\r\n'

SERIAL_BAUDRATE = 19200

async def open_connection(loop, transport, **kwargs):
    return await serial.aio.create_serial_connection(
        None,
        Protocol,
        transport, **kwargs)
    asyncio.ensure_future(coro())

class Protocol(asyncio.StreamReaderProtocol):

    def connection_made(self, transport):
        pass

    def connection_lost(exc):
        pass


class PowerSupply(Subsystem):
    systype = "PowerSupply"
    next_id = 0

    def __init__(self, location):
        super().__init__(location)
        self.serial_port = serial.Serial(
            baudrate=SERIAL_BAUDRATE,
            bytesize=serial.EIGHTBITS,
		    parity=serial.PARITY_NONE,
		    timeout=1
        )

    def set_voltage(self, new_voltage):
        pass

    def set_current(self, new_voltage):
        pass

    def serial_write(self, data):
        pass

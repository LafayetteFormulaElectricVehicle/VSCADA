# Copyright 2016 Domenick Falco

import asyncio
import time
import struct
import math

import scadad.message_bus
from .subsystem import Subsystem
from scadad.measurand import Measurand
from scadad.controllable import Controllable



mb = scadad.message_bus.getbus()

GEAR_RATIO = 2.5
WHEEL_RADIUS = 0.000142045 # In miles
WHEEL_RADIUS_METRIC = 0.0002285992685 #In kilometers
RPM2SPEED = GEAR_RATIO * 2 * math.pi * WHEEL_RADIUS * 1/60
RPM2SPEED_METRIC = GEAR_RATIO * 2 * math.pi * WHEEL_RADIUS_METRIC * 1/60

def make_safe_handler(func):
    '''Decorator to catch exceptions in handlers.
    '''
    async def wrapper(*args):
        try:
            await func(*args)
        except struct.error as e:
            print('{}: Bad Message {}\n{}'.format(repr(args[0]), args[1], e))

    return wrapper



class TractiveSystemManager(Subsystem):
    systype = 'TractiveSystemManager'
    next_id = 0

    def __init__(self, system, *args):
        super().__init__('virtual')

        # Get a MotorController from the system
        mcs = list(filter(lambda x: x.systype == 'MotorController',
            system.subsystems.values()))
        self.mc = mcs[0]

        # Get a TractiveSystemController from the system
        tsc = list(filter(lambda x: x.systype == 'TractiveSystemController',
            system.subsystems.values()))
        self.tsc = tsc[0]

        # Get a DC from the system
        dc = list(filter(lambda x: x.systype == 'DynomometerController',
            system.subsystems.values()))
        self.dc = dc[0]

        # Setup model
        self.measurands = {}
        self.controllables = {}
        self.subsystems = {}

        ####TractiveSystemController Values
        self.measurands['physical_throttle'] = Measurand('%')

        self.controllables = self.tsc.controllables


        ####Motor Controller Values
        self.measurands['motor_rpm'] = Measurand('RPM')
        self.measurands['motor_temperature'] = Measurand('Celcius')
        self.measurands['rms_current'] = Measurand('Amperes')
        self.measurands['cap_voltage'] = Measurand('Volts')
        self.measurands['reverse'] = Measurand('Boolean')


        ###Dyno Controller Values
        self.controllables['valve_position'] = self.dc.valve_position

        ####Unique Calculated Values
        self.measurands['speed'] = Measurand('mph')
        self.measurands['speed_metric'] = Measurand('kmph')
        self.measurands['faulted'] = Measurand('Boolean')


        for k, v in self.measurands.items():
            v.location = [self.name, k]

        for k, v in self.controllables.items():
            v.location = [self.name, k]

        asyncio.ensure_future(self.read_bus())

    async def read_bus(self):
         async for msg in mb:
             if msg['type'] == 'MotorController':
                 ##literal values
                 self.measurands['motor_rpm'] = msg['motor_rpm']
                 self.measurands['motor_temperature'] = msg['motor_temperature']
                 self.measurands['rms_current'] = msg['rms_current']
                 self.measurands['cap_voltage'] = msg['cap_voltage']
                 self.measurands['reverse'] = msg['reverse']

                 ##Interpreteed values
                 if(msg['fault1'].calibrated != 'No Fault' or msg['fault1'].calibrated != 'No Fault'):
                     self.measurands['faulted'].update(True)
                 else:
                    self.measurands['faulted'].update(False)

                 self.measurands['speed'].update(msg['motor_rpm'].calibrated * RPM2SPEED)
                 self.measurands['speed_metric'].update(msg['motor_rpm'].calibrated * RPM2SPEED_METRIC)


                 #await mb.dispatch(self.toDict())
             if msg['type'] == 'TractiveSystemController':
                 self.measurands['physical_throttle'] = msg['physical_throttle']

            #  if d['type'] == 'controllable':
            #      name = d['name']
            #      if name in self.controllables:
            #          c = self.controllables[name]
            #          c.applyDict(d)

    def applyDict(self, d):
        if d['type'] == 'controllable':
            name = d['location'][-1]
            if name in self.controllables:
                c = self.controllables[name]
                if c.set_input(d['input']):
                    asyncio.ensure_future(mb.dispatch(c.toDict()))
                asyncio.ensure_future(self.update_controllables())

    async def update_controllables(self):
        in_sync = True
        for c in self.controllables.values():
            in_sync = in_sync and c.in_sync
            #print(c.location[-1], c.in_sync, c.input, c.actual)


    def toDict(self):
        d = super().toDict()
        d['is_virtual'] = True
        for k, v in self.controllables.items():
            d[k] = v.toDict()
        for k, v in self.measurands.items():
            d[k] = v.toDict()
        return d

# Copyright 2016 Brendon Carroll
import asyncio
import struct
import time

from .subsystem import Subsystem

class Heartbeat(Subsystem):
    systype = 'Heartbeat'
    next_id = 0

    def __init__(self, system, *args):
        super().__init__('virtual')
        self.online = True
        self.system = system
        self.bus = system.networks[args[0]]
        self.addr = int(args[1])
        self.starttime = time.time()

        asyncio.ensure_future(self.pulse())
        #data that we should be logging
        self.dataToBeLogged = []

    async def pulse(self):
        while True:
            uptime = round(time.time() - self.starttime)
            data = struct.pack('!I', int(uptime))
            await self.bus.send(self.addr, data)
            await asyncio.sleep(1)

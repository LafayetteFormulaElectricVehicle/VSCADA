# Copyright 2016 Brendon Carroll
import asyncio

from .subsystem import Subsystem

class RougeCANMonitor(Subsystem):
    systype = 'RougeCANMonitor'
    next_id = 0

    def __init__(self, system, *args):
        super().__init__('virtual')
        self.system = system
        self.bus = system.networks[args[0]]
        self.messages = []
        self.rtraffic_detected = False
        asyncio.ensure_future(self.read_loop())
        #data that we should be logging
        self.dataToBeLogged = []

    async def read_loop(self):
        q = self.bus.get_default_queue()
        while True:
            self.rtraffic_detected = True
            msg = await q.get()
            self.messages.append(msg)

    def toDict(self):
        d = super().toDict()
        d['bus'] = repr(self.bus)
        messages = []
        for m in self.messages:
            messages.append(str(m))
        d['messages'] = messages
        d['dataToBeLogged'] = self.dataToBeLogged
        return d

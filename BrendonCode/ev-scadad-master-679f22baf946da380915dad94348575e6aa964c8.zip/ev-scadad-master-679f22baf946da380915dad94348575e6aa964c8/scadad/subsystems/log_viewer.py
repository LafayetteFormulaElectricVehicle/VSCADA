# Copyright 2016 Domenick Falco


from .subsystem import Subsystem

class LogViewer(Subsystem):

    systype = 'LogViewer'
    next_id = 0

    def __init__(self, system, *args):
        super().__init__('virtual')
        #data that we should be logging
        self.dataToBeLogged = []


    def toDict(self):
        d = super().toDict()
        d['is_virtual'] = True
        d['dataToBeLogged'] = self.dataToBeLogged
        return d

    def applyDict(self, d):
        name = d['name']
        if name == 'thing':
            self.thing = d['input']

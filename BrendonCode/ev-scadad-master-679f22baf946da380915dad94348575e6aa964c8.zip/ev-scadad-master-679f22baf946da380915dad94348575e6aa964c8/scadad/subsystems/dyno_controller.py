# Copyright 2016 Brendon Carroll

import asyncio
import struct

import scadad.message_bus
mb = scadad.message_bus.getbus()

from .subsystem import Subsystem, make_safe_handler
from scadad.controllable import Controllable
from scadad.measurand import Measurand
from scadad.watchdog import Watchdog

TORQUE_CF = lambda x: x
OIL_TEMP_CF = lambda x: 0.007629395 * x

WATCHDOG_TIMEOUT = 2

class DynomometerController(Subsystem):
    systype = 'DynomometerController'
    next_id = 0

    def __init__(self, location):
        super().__init__(location)
        self.network, self.address = location
        self.addr1 = self.address[0]
        self.addr2 = self.address[1]

        self.wt = Watchdog(WATCHDOG_TIMEOUT, self.set_offline)

        # Setup Model
        self.valve_position = Controllable(64000, minv=0, maxv=(2**16-1), step=1000)
        self.valve_position.location = [self.name, 'valve_position']
        self.torque = Measurand('ftlbs', TORQUE_CF)
        self.oil_temperature = Measurand('C', OIL_TEMP_CF)
        self.oil_temperature.location = [self.name, 'torque']
        self.torque.location = [self.name, 'torque']

        self.network.on_route(self.addr1, self.handle_addr1)

    async def handle_addr1(self, msg):
        ''' Valve position 16'b
            Torque 16'b
            Oil Temp 16'b
        '''
        data = struct.unpack('>HHH', msg.data)
        # Measurands
        if self.torque.update(data[1], timestamp=msg.timestamp):
            await mb.dispatch(self.torque.toDict())
        if self.oil_temperature.update(data[2], timestamp=msg.timestamp):
            await mb.dispatch(self.oil_temperature.toDict())

        self.made_contact()
        # Controllables
        self.valve_position.set_actual(data[0])

    async def update_controllables(self):
        if not self.valve_position.in_sync:
            data = struct.pack('>H', self.valve_position.input)
            await self.network.send(self.addr2, data)

    def applyDict(self, d):
        if d['type'] == 'controllable' and d['location'][-1] == 'valve_position':
            self.valve_position.set_input(d['input'])
            asyncio.ensure_future(self.update_controllables())

    def toDict(self):
        d = super().toDict()
        d['valve_position'] = self.valve_position.toDict()
        d['torque'] = self.torque.toDict()
        d['oil_temperature'] = self.oil_temperature.toDict()
        return d

# Copyright 2016 Brendon Carroll

import asyncio
import struct
import time


from .subsystem import Subsystem
from scadad.measurand import Measurand
from scadad.watchdog import Watchdog
import scadad.message_bus

mb = scadad.message_bus.getbus()

WATCHDOG_TIMEOUT = 0.100

#The time to wait from recieving one CAN message until you can recieve another
COOLDOWN_TIME = 5 # seconds

#mutply COOLDOWN_TIME by this value to get proper behavior
TIME_CALIBRATION = 0.065

FAULT_CODES = {
    0:  'No Fault',
    12: 'Controller Overcurrent',
    13: 'Current Sensor Fault',
    14: 'Precharge Failed',
    17: 'Severe Undervoltage',
    18: 'Severe Overvoltage',
    22: 'Controller Overtemp Cutback',
    23: 'Undervoltage Cutback',
    24: 'Overvoltage Cutback',
    25: '5V Supply Failure',
    28: 'Motor Temp Hot Cutback',
    29: 'Motor Temp Sensor Fault',
    31: 'Main Open/Short',
    36: 'Encoder Fault',
    37: 'Motor Open',
    38: 'Main Contactor Welded',
    39: 'Main Contactor Did Not Close',
    41: 'Throttle Wiper High',
    42: 'Throttle Wiper Low',
    43: 'Pot2 Wiper High',
    44: 'Pot2 Wiper Low',
    45: 'Pot Low Overcurrent',
    46: 'EEPROM Failure',
    49: 'Parameter Change Fault',
    51: 'No CAN Communication from Primary',
    52: 'Fault from Secondary',
    54: 'No CAN Bus Traffic from Secondary Controller',
    55: 'BMS Communication Fault',
    56: 'Program Mode',
}

class MotorController(Subsystem):
    systype = 'MotorController'
    next_id = 0

    def __init__(self, location):
        super().__init__(location)
        self.network, self.address = location
        [self.addr1, self.addr2] = self.address

        self.t_addr1 = time.process_time()
        self.t_addr2 = time.process_time()

        self.wt = Watchdog(WATCHDOG_TIMEOUT, self.set_offline)

        # Setup model
        self.measurands = {}
        self.measurands['motor_rpm'] = Measurand('RPM')
        self.measurands['motor_temperature'] = Measurand('Celcius')
        self.measurands['controller_temperature'] = Measurand('Celcius')
        self.measurands['rms_current'] = Measurand('Amperes')
        self.measurands['cap_voltage'] = Measurand('Volts')

        self.measurands['stator_frequency'] = Measurand('Hz')
        self.measurands['controller_fault1'] = Measurand('Fault')
        self.measurands['controller_fault2'] = Measurand('Fault')
        self.measurands['throttle_input'] = Measurand('%')
        self.measurands['brake_input'] = Measurand('%')

        self.measurands['econo'] = Measurand('Boolean')
        self.measurands['regen'] = Measurand('Boolean')
        self.measurands['reverse'] = Measurand('Boolean')
        self.measurands['brake_light'] = Measurand('Boolean')

        self.network.on_route(self.addr1, self.handle_addr1)
        self.network.on_route(self.addr2, self.handle_addr2)

    async def handle_addr1(self, msg):
        if ((time.process_time() - self.t_addr1) > COOLDOWN_TIME*TIME_CALIBRATION):
            data = msg.data
            d = {}
            s = struct.unpack('!HBBHH', data)
            d['motor_rpm'] = s[0]
            d['motor_temperature'] = s[1] * 240/256 - 40
            d['controller_temperature'] = s[2] * 240/256 - 40
            d['rms_current'] = s[3] * 0.1
            d['cap_voltage'] = s[4] * 0.1



            if self.batch_change_measurands(d, msg.timestamp):
                await mb.dispatch(self.toDict())
            self.t_addr1 = time.process_time()
        self.made_contact()

    async def handle_addr2(self, msg):
        if ((time.process_time() - self.t_addr2) > COOLDOWN_TIME*TIME_CALIBRATION):
            data = msg.data
            d = {}
            s = struct.unpack('!HBBBBB', data[0:7])
            d['stator_frequency'] = s[0]
            fault1 = s[1]
            fault2 = s[2]
            d['throttle_input'] = s[3]
            d['brake_input'] = s[4]
            system_bits = s[5]

            try:
                d['controller_fault1'] = "{}: {}".format(fault1, FAULT_CODES[fault1])
                d['controller_fault2'] = "{}: {}".format(fault2, FAULT_CODES[fault2])
            except KeyError:
                print('Unrecognized fault code', str(fault1), str(fault2))

            d['econo'] = (system_bits & 0x1) != 0
            d['regen'] = (system_bits & 0x2) != 0
            d['reverse'] = (system_bits & 0x4) != 0
            d['brake_light'] = (system_bits & 0x8) != 0

            if self.batch_change_measurands(d, msg.timestamp):
                await mb.dispatch(self.toDict())
            self.t_addr2 = time.process_time()

        self.made_contact()

    def batch_change_measurands(self, d, timestamp):
        change = False
        for k, v in d.items():
            m = self.measurands[k]
            c = m.update(v, timestamp=timestamp)
            change = change or c
        return change

    def toDict(self):
        d = super().toDict()
        for k, v in self.measurands.items():
            d[k] = v.toDict()
        return d

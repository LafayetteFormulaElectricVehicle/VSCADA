from .subsystem import Subsystem

class GPS(Subsystem):
    systype = "GPS"
    next_id = 0

    def __init__(self, location):
        super().__init__(location)
        #data that we should be logging
        self.dataToBeLogged = []

    def toDict(self):
        d = super().toDict()
        d['dataToBeLogged'] = self.dataToBeLogged
        return d

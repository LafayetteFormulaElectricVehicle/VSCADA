# Copyright 2016 Domenick Falco

import asyncio
import time
import struct
import math
import socket

import scadad.message_bus
from .subsystem import Subsystem
from scadad.measurand import Measurand
from scadad.controllable import Controllable

mb = scadad.message_bus.getbus()


SAFETY_DICT = {
    'pack_voltage' :         {'location': ['BatteryPack-0', 'voltage'],
                              'warning' : '>3.7',
                              'failure' : '>4.0',
                              'units'   : 'Volts'
                              },
    'motor_temperature':     {'location': ['MotorController-0', 'temperature'],
                              'failure' : '>80',
                              'units'   : 'Celcius'
                              },
    'cell_one_voltage' :         {'location': ['BatteryPack-0', 'cells', 0, 'voltage'],
                              'warning' : '>50',
                              'failure' : '>65',
                              'units'   : 'Volts'
                              },
}

class SafetyManager(Subsystem):
    systype = 'SafetyManager'
    next_id = 0

    def __init__(self, system, *args):
        super().__init__('virtual')

        self.task = None
        self.socket = socket.socket(socket.AF_INET)
        self.socket.setblocking(False)
        self.loop_closed = True

        # Setup model
        self.measurands = {}
        self.controllables = {}

        self.measurands['safety_looped_triggered'] = Measurand('Boolean')
        self.measurands['safety_looped_triggered'].update(False)

        for k, v in SAFETY_DICT.items():
            self.measurands[k] = Measurand(v['units'])
            if 'warning' in v:
                self.measurands[k + '_warning'] = Measurand('Boolean')
                self.measurands[k + '_warning'].update(False)
                self.controllables[k + '_warning_toggle'] = Controllable(True)
            if 'failure' in v:
                self.measurands[k + '_failure'] = Measurand('Boolean')
                self.measurands[k + '_failure'].update(False)
                self.controllables[k + '_failure_toggle'] = Controllable(True)
                self.controllables[k + '_reset'] = Controllable(False)


        for k, v in self.measurands.items():
            v.location = [self.name, k]

        for k, v in self.controllables.items():
            v.location = [self.name, k]

        asyncio.ensure_future(self.read_bus())
        asyncio.ensure_future(self.keep_safety_closed())

    async def open_loop(self):
        self.loop_closed = False
        self.socket.sento(b'\x00', ('127.0.0.1',6666))

    async def keep_safety_closed(self):
        while True:
            if self.loop_closed:
                self.socket.sendto(b'\x01', ('127.0.0.1',6666))
            await asyncio.sleep(0.150)

    async def read_bus(self):
         async for msg in mb:
             for k, v in SAFETY_DICT.items():
                 dataType = v['location']
                 if(len(dataType) == 2):
                     if msg['location'][0] == dataType[0]:
                         if msg['location'][1] == dataType[1]:
                              self.measurands[k].update(msg['calibrated'])
                              self.heck_safety(k, msg['calibrated'])
                 elif(len(dataType) == 4):
                     if msg['location'][0] == dataType[0]:
                         if msg['location'][1] == dataType[1]:
                             if msg['location'][2] == dataType[2]:
                                 if msg['location'][3] == dataType[3]:
                                      self.measurands[k].update(msg['calibrated'])
                                      self.check_safety(k, msg['calibrated'])
                 else:
                     print('invalid location detectected')

    def check_safety(self, safetyMeasurand, detectedValue):
        if 'warning' in SAFETY_DICT[safetyMeasurand]:
            if self.controllables[safetyMeasurand + '_warning_toggle'].toDict()['actual']:
                if(SAFETY_DICT[safetyMeasurand]['warning'][0] == '>'):
                    if(detectedValue > float(SAFETY_DICT[safetyMeasurand]['warning'][1:])):
                        self.measurands[safetyMeasurand + '_warning'].update(True)
                    else:
                        self.measurands[safetyMeasurand + '_warning'].update(False)
                elif(SAFETY_DICT[safetyMeasurand]['warning'][0] == '<'):
                    if(detectedValue < float(SAFETY_DICT[safetyMeasurand]['warning'][1:])):
                        self.measurands[safetyMeasurand + '_warning'].update(True)
                    else:
                        self.measurands[safetyMeasurand + '_warning'].update(False)
        if 'failure' in SAFETY_DICT[safetyMeasurand]:
            if self.controllables[safetyMeasurand + '_failure_toggle'].toDict()['actual']:
                if(SAFETY_DICT[safetyMeasurand]['failure'][0] == '>'):
                    if(detectedValue > float(SAFETY_DICT[safetyMeasurand]['failure'][1:])):
                        self.measurands[safetyMeasurand + '_failure'].update(True)
                        self.measurands['safety_looped_triggered'].update(True)
                        self.open_loop()
                elif(SAFETY_DICT[safetyMeasurand]['warning'][0] == '<'):
                    if(detectedValue < float(SAFETY_DICT[safetyMeasurand]['failure'][1:])):
                        self.measurands[safetyMeasurand + '_failure'].update(True)
                        self.measurands['safety_looped_triggered'].update(True)
                        self.open_loop()

    def reset_failure(self, c):
        variable_reset = c.toDict()['location'][-1][0:-6]
        self.measurands[variable_reset + '_failure'].update(False)
        c.set_actual_and_input(False)
        self.loop_closed = True

    async def update_controllables(self):
        in_sync = True
        for c in self.controllables.values():
            in_sync = in_sync and c.in_sync
            #print(c.location[-1], c.in_sync, c.input, c.actual)
        if not in_sync:
            if self.task is None or self.task.done():
                await self.send_addr2()

    def applyDict(self, d):
        if d['type'] == 'controllable':
            name = d['location'][-1]
            if name in self.controllables:
                c = self.controllables[name]
                #only use for virtual sub
                if c.set_actual_and_input(d['input']):
                    asyncio.ensure_future(mb.dispatch(c.toDict()))
                if "_reset" in c.toDict()['location'][-1]:
                    self.reset_failure(c)

    def toDict(self):
        d = super().toDict()
        d['is_virtual'] = True
        for k, v in self.controllables.items():
            d[k] = v.toDict()
        for k, v in self.measurands.items():
            d[k] = v.toDict()
        d['safety_dict'] = SAFETY_DICT
        return d

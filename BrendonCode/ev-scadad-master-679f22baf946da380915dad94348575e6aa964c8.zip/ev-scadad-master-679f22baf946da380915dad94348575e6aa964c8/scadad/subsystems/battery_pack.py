# Copyright 2016 Brendon Carroll

import asyncio
import time
import struct

import scadad.message_bus
from .subsystem import Subsystem, make_safe_handler
from scadad.measurand import Measurand
from scadad.watchdog import Watchdog
from scadad.plot import Plot

mb = scadad.message_bus.getbus()

PACK_MODES = [
    'BOOT',
    'CHARGE',
    'CHARGED',
    'LOW CURRENT OUTPUT',
    'FAULT',
    'DEAD',
    'READY',
]

NUM_CELL = 7

#The time to wait from recieving one CAN message until you can recieve another
COOLDOWN_TIME = .1 # seconds

#mutply COOLDOWN_TIME by this value to get proper behavior
TIME_CALIBRATION = 0.065

PACK_MODE_CF = lambda x: PACK_MODES[x]
PACK_VOLTAGE_CF = lambda x: x/10
PACK_CURRENT_CF = lambda x: x/1000
PACK_UPTIME_CF = lambda x: x/100
PACK_COULOMBS_CF = lambda x: x/1000
PACK_SOC_CF = lambda x: x

CELL_STATUS = [
    'NOT BYPASS',
    'BYPASS'
]
CELL_STATUS_CF = lambda x: CELL_STATUS[x]
CELL_VOLTAGE_CF = lambda x: x/1000
CELL_TEMPERATURE_CF = lambda x: x/10

WATCHDOG_TIMEOUT = 1 # seconds

CELL_VOLTAGE_GRAPH_SAMPLE_PERIOD = 60 # seconds
CELL_VOLTAGE_GRAPH_SAMPLE_POINTS = 30 # points

class Cell(object):
    '''Represents a single cell in a battery pack.
    '''
    def __init__(self, location, num):
        self.num = num
        self.temperature = Measurand('Celcius', CELL_TEMPERATURE_CF, location=[location, 'cells', num, 'temperature'])
        self.voltage = Measurand('Volts', CELL_VOLTAGE_CF, location=[location, 'cells', num, 'voltage'])
        self.status = Measurand('Status', CELL_STATUS_CF, location=[location, 'cells', num, 'status'])

    def toDict(self):
        return {
            'num': self.num,
            'temperature': self.temperature.toDict(),
            'voltage': self.voltage.toDict(),
            'status': self.status.toDict()
        }

class BatteryPack(Subsystem):
    '''A battery pack model.  Has information about individual cell voltage
    and temperature, pack state of charge, and pack status.
    '''
    systype = 'BatteryPack'
    next_id = 0

    def __init__(self, location):
        super().__init__(location)
        self.network, self.address = location
        self.addr1 = self.address[0]
        self.addr2 = self.address[1]
        self.addr3 = self.address[2]

        self.t_addr1 = time.process_time()
        self.t_addr2 = time.process_time()
        self.t_addr3 = time.process_time()

        self.wt = Watchdog(WATCHDOG_TIMEOUT, self.set_offline)

        # Setup model
        self.cells = []
        for i in range(NUM_CELL):
            self.cells.append(Cell(self.name, i))

        self.measurands = {
            'mode' : Measurand('Mode', PACK_MODE_CF),
            'pack_voltage' : Measurand('Volts', PACK_VOLTAGE_CF),
            'pack_current' : Measurand('Amperes', PACK_CURRENT_CF),
            'state_of_charge' :  Measurand('%', PACK_SOC_CF),
            'uptime': Measurand('s', PACK_UPTIME_CF),
            'total_coulombs': Measurand('Coulombs', PACK_COULOMBS_CF),
        }
        for k, v in self.measurands.items():
            v.location = [self.name, k]

        self.plots = {
            'cell_voltage': Plot([self.name,'cell_voltage'],[[self.name, 'cells', 0, 'voltage'],
                                                             [self.name, 'cells', 1, 'voltage'],
                                                             [self.name, 'cells', 2, 'voltage'],
                                                             [self.name, 'cells', 3, 'voltage'],
                                                             [self.name, 'cells', 4, 'voltage'],
                                                             [self.name, 'cells', 5, 'voltage'],
                                                             [self.name, 'cells', 6, 'voltage']], CELL_VOLTAGE_GRAPH_SAMPLE_PERIOD, CELL_VOLTAGE_GRAPH_SAMPLE_POINTS),
        }

        # Setup handlers
        self.network.on_route(self.addr1, self.handle_addr1)
        self.network.on_route(self.addr2, self.handle_addr2)
        self.network.on_route(self.addr3, self.handle_addr3)

    @make_safe_handler
    async def handle_addr1(self, msg):
        data = struct.unpack('>BHiB', msg.data)
        if ((time.process_time() - self.t_addr1) > COOLDOWN_TIME*TIME_CALIBRATION):
            d = {
                'mode': data[0],
                'pack_voltage': data[1],
                'pack_current': data[2],
                'state_of_charge': data[3],
            }
            for k, v in d.items():
                m = self.measurands[k]
                if m.update(v, timestamp=msg.timestamp):
                    await mb.dispatch(m.toDict())
            self.t_addr1 = time.process_time()
        self.made_contact()

    @make_safe_handler
    async def handle_addr2(self, msg):
        if ((time.process_time() - self.t_addr2) > COOLDOWN_TIME*TIME_CALIBRATION):
            uptime, total_coulombs = struct.unpack('>Ii', msg.data)
            if self.measurands['uptime'].update(uptime, timestamp=msg.timestamp):
                await mb.dispatch(self.measurands['uptime'].toDict())
            if self.measurands['total_coulombs'].update(total_coulombs,timestamp=msg.timestamp):
                await mb.dispatch(self.measurands['total_coulombs'].toDict())
            self.t_addr2 = time.process_time()
        self.made_contact()

    @make_safe_handler
    async def handle_addr3(self, msg):
        data = struct.unpack('>BBHH', msg.data)
        if ((time.process_time() - self.t_addr3) > COOLDOWN_TIME*TIME_CALIBRATION):
            num, status, voltage, temperature = data

            cell = self.cells[num]
            if cell.voltage.update(voltage, timestamp=msg.timestamp):
                await mb.dispatch(cell.voltage.toDict())
            if cell.temperature.update(temperature, timestamp=msg.timestamp):
                await mb.dispatch(cell.temperature.toDict())
            if cell.status.update(status, timestamp=msg.timestamp):
                await mb.dispatch(cell.status.toDict())
            self.t_addr3 = time.process_time()
        self.made_contact()

    async def update_plots(self):
        in_sync = True
        for c in self.plots.values():
            in_sync = in_sync and c.in_sync
            #print(c.location[-1], c.in_sync, c.input, c.actual)

    def applyDict(self, d):
        print('APPLY')
        if d['type'] == 'plot':
            name = d['location'][-1]
            if name in self.controllables:
                c = self.controllables[name]
                if c.set_input(d['input']):
                    asyncio.ensure_future(mb.dispatch(c.toDict()))
                asyncio.ensure_future(self.update_plots())

    def toDict(self, graphs=False):
        d = super().toDict()

        cells = []
        for i in range(NUM_CELL):
            cell = self.cells[i]
            cells.append(cell.toDict())
        d['cells'] = cells

        for k, m in self.measurands.items():
            d[k] = m.toDict()

        for k, p in self.plots.items():
            d[k] = p.toDict()

        return d

import abc
import time
import asyncio
import struct

from scadad.watchdog import Watchdog

def make_safe_handler(func):
    '''Decorator to catch exceptions in handlers.
    '''
    async def wrapper(*args):
        try:
            await func(*args)
        except struct.error as e:
            print('{}: Bad Message {}\n{}'.format(repr(args[0]), args[1], e))

    return wrapper

class Subsystem(abc.ABC):

    @classmethod
    def get_id_num(self):
        id_num = self.next_id
        self.next_id += 1
        return id_num

    def __init__(self, location):
        self.id_num = self.get_id_num()
        self.location = location
        self.online = False
        self.timestamp = None
        self.name = repr(self)

    def __repr__(self):
        return self.systype + '-' + str(self.id_num)

    def __str__(self):
        return '{} @ {}'.format(repr(self), self.location)

    def set_offline(self):
        self.online = False

    def made_contact(self):
        self.wt.reset()
        self.online = True
        self.timestamp = time.time()

    def toDict(self):
        d = {
            'type': 'subsystem',
            'systype': self.systype,
            'location': str(self.location),
            'online': self.online,
            'name': self.name,
        }
        if self.timestamp is not None:
            d['timestamp'] = self.timestamp
        return d

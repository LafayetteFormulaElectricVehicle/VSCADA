# Copyright 2016 Domenick Falco

from .subsystem import Subsystem

class BatteryManager(Subsystem):

    systype = 'BatteryManager'
    next_id = 0

    def __init__(self, system):
        super().__init__('virtual')

        # Get BatteryPacks from the system
        bp = list(filter(lambda x: x.systype == 'BatteryPack',
            system.subsystems.values()))

        self.measurands = {}
        for bpn in bp:
            for m in bpn.measurands:
                self.measurands[str(bpn.measurands[m].toDict()['location'][0]) + '_' + m] = bpn.measurands[m]



    def toDict(self):
        d = super().toDict()
        d['is_virtual'] = True
        for k, v in self.measurands.items():
            d[k] = v.toDict()
        return d

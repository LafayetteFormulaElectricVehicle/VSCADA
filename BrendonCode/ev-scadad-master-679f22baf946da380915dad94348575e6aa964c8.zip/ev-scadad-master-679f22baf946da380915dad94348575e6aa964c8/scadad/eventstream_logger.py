# Copyright 2016 Brendon Carroll

import asyncio
import json
import os
import queue
import threading

import scadad.message_bus
mb = scadad.message_bus.getbus()

def get_filename(system):
    directory = scadad.config.get('data_directory')
    filename = '{}-{}.log'.format(
        system.name,
        system.starttime.isoformat().replace(':', '')
    )
    return os.path.join(directory, filename)

class EventStreamLogger(object):

    def __init__(self, system):
        filename = get_filename(system)
        self.system = system
        self.f = open(filename, 'a')
        self.q = queue.Queue() # Synchronized queue.
        self.loop = asyncio.get_event_loop()
        self.running = threading.Lock()
        self.bytes_logged = 0

        asyncio.ensure_future(self.read_bus())
        asyncio.ensure_future(self.print_bytes())
        self.start_processing()

    async def print_bytes(self):
        while True:
            await asyncio.sleep(10)
            print(self.bytes_logged, 'bytes logged.')

    async def read_bus(self):
        data = json.dumps(self.system.toDict())
        self.add_to_queue(data)

        async for msg in mb:
            if msg['type'] not in ['plot']:
                data = '\n' + json.dumps(msg)
                self.add_to_queue(data)
                self.bytes_logged += len(data)


    def add_to_queue(self, data):
        self.q.put_nowait(data)
        if self.running.acquire(False):
            self.running.release()
            self.start_processing()

    def write_to_disk(self):
        try:
            with self.running:
                while True:
                    data = self.q.get_nowait()
                    self.f.write(data)
                    self.q.task_done()
        except queue.Empty:
                pass

    def start_processing(self):
        self.fut = self.loop.run_in_executor(None, self.write_to_disk)

    def __del__(self):
        self.q.join()
        self.f.close()

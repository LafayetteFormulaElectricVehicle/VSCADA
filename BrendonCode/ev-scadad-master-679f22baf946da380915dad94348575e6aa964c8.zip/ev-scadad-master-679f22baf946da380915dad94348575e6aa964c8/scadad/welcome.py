import time

messages = [
    'Unacceptable!',
    'I have context free conversations',
    '-1',
    '"Not everything worth doing is worth doing well." --Tom West',
    'The savings are unbelievable!',
    "You're welcome to bring in as much material as you want, but eventually you'll run into an indexing problem.",
    'Take the box; flip it around.',
    "I'm going to get out of here before someone asks me a question",
    'Please remove all clothing before handling high voltage.',
]

def get_msg():
    message = messages[(round(time.time()) // 60) % len(messages)]
    return 'Message of the Day: "{}"'.format(message)

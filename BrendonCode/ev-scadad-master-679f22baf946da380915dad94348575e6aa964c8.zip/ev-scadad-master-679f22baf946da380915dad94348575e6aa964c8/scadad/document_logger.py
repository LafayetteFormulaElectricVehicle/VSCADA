# Copyright 2016 Brendon Carroll

import os
import asyncio

from datetime import datetime

import scadad.config
import scadad.message_bus
mb = scadad.message_bus.getbus()
filename = 'log.csv'
csv_columns = [
    'time'
]

def get_filename(system):
    directory = scadad.config.get('data_directory')
    filename = '{}-{}.json'.format(
        system.name,
        system.starttime.isoformat().replace(':', '')
    )
    return os.path.join(directory, filename)

class DocumentLogger(object):
    '''A class for logging documents (dictionaries, JSON objects) in
    tinydb.  tinydb blocks so we have a thread to take care of
    the blocking IO and we throw objects in a queue.
    '''

    def __init__(self, system):





        with open(filename, "a") as logfile:
            logfile.write('time')
            # print(system.toDict())
            for subsystems, value in system.toDict()['subsystems'].items():
                # print(subsystems)
                for dataToBeLogged in system.toDict()['subsystems'][subsystems]['dataToBeLogged']:
                    # print(subsystems + '.' + dataToBeLogged)
                    logfile.write("," + subsystems + '.' + dataToBeLogged)
                    csv_columns.append(subsystems + '.' + dataToBeLogged)

            logfile.write('\n')

        self.loop = asyncio.get_event_loop()
        self.loop.create_task(self.log_data())

    async def log_data(self):
        timepassed = 0
        with open(filename, "a") as logfile:

            while int(timepassed) < 7200:
                for dataToBeLogged in csv_columns:
                    if(dataToBeLogged == 'time'):
                        logfile.write(str(timepassed))
                    else:
                        logfile.write(',123.456')
                logfile.write('\n')
                timepassed += .5
                await asyncio.sleep(.5)
            print('done')

            
    def __repr__(self):
        return 'document_logger'


if __name__ == '__main__':
    class MockSystem(object):
        def __init__(self):
            self.name = 'TestEV1'
            self.starttime = datetime.now()

    dl = DocumentLogger(MockSystem())

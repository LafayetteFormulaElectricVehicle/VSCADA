# Copyright 2016 Brendon Carroll

import asyncio
import struct
import random
import time
import json
import sys


IGNORE_CONTROLLABLES = True;

class CSV(object):


    def __init__(self, input_file, output_file='default.csv', timestep=1):

        self.input_file = open(input_file, 'r')
        self.output_file = open(output_file, 'w')
        self.timestep = timestep

        self.ReadSystemLine()

        print('Converting.....'),

        self.WriteData()

        print('DONE!')

    def __repr__(self):
        return 'document_logger'

    def ReadSystemLine(self):

        system = json.loads(self.input_file.readline())

        subsystem_list = []
        ##populate list of subsystems then order alphabetically
        for subsystem, value in system['subsystems'].items():
            subsystem_list.append(subsystem)


        self.measurands_recorded = []
        for subsystem in subsystem_list:
            subsystem_props = system['subsystems'][subsystem].items()
            for dataToBeLogged in subsystem_props:
                if(type(dataToBeLogged[1]) == dict):
                    self.measurands_recorded.append(subsystem + '.' + str(dataToBeLogged[0]))
                if(type(dataToBeLogged[1]) == list):
                    for inner_subsystem in dataToBeLogged[1]:
                        if(type(inner_subsystem) == dict):
                            for inner_subsystem_measurand in inner_subsystem:
                                if(inner_subsystem_measurand != 'num'):
                                    self.measurands_recorded.append(subsystem + '.' + dataToBeLogged[0] + '-' + str(inner_subsystem['num']) + '.' + inner_subsystem_measurand)
        self.measurands_recorded.sort()

    def WriteData(self):
        most_recent_data = []




        for i in range(len(self.measurands_recorded)):
            most_recent_data.append('n/a')

        #Write in all the Column headers
        self.output_file.write('time')
        for m in self.measurands_recorded:
            self.output_file.write(',' + m)

        #use the first msg recieved as 0-time
        line = self.input_file.readline()
        #An empty line means you've hit the end
        if len(line.strip()) == 0:
            return
        first_msg = json.loads(line.strip())
        self.last_write_time = first_msg['timestamp']
        self.current_time = first_msg['timestamp']
        self.display_time = 0



        #update the value in the message
        if len(first_msg['location']) == 2:
            measurand = first_msg['location'][0] + '.' + first_msg['location'][1]
        elif len(first_msg['location']) == 4:
            measurand = first_msg['location'][0] + '.' + first_msg['location'][1] + '-' + str(first_msg['location'][2]) + '.' + first_msg['location'][3]
        else:
            print("error reading location of message")

        if(first_msg['type'] == 'measurand'):
            most_recent_data[self.measurands_recorded.index(measurand)] = first_msg['calibrated']
        elif(first_msg['type'] == 'controllable'):
            most_recent_data[self.measurands_recorded.index(measurand)] = first_msg['actual']
        else:
            print("error reading message type" + first_msg['type'])

        #Parse the remainder of the file
        for line in self.input_file:

            #An empty line means you've hit the end
            if len(line.strip()) == 0:
                break

            msg = json.loads(line.strip())

            self.current_time = msg['timestamp']
            time_difference = self.current_time - self.last_write_time

            #update the value in the message
            if len(msg['location']) == 2:
                measurand = msg['location'][0] + '.' + msg['location'][1]
            elif len(msg['location']) == 4:
                measurand = msg['location'][0] + '.' + msg['location'][1] + '-' + str(msg['location'][2]) + '.' + msg['location'][3]
            else:
                print("error reading location of message")

            if(msg['type'] == 'measurand'):
                most_recent_data[self.measurands_recorded.index(measurand)] = msg['calibrated']
            elif(msg['type'] == 'controllable'):
                most_recent_data[self.measurands_recorded.index(measurand)] = msg['actual']
            else:
                print("error reading message type" + msg['type'])


            while(time_difference >= self.timestep):
                self.display_time = self.display_time + self.timestep
                self.output_file.write('\n' + str(round(self.display_time*1000)/1000))
                for val in most_recent_data:
                    self.output_file.write(',' + str(val))
                self.last_write_time = self.last_write_time + self.timestep
                time_difference = self.current_time - self.last_write_time


        self.output_file.write('\n')

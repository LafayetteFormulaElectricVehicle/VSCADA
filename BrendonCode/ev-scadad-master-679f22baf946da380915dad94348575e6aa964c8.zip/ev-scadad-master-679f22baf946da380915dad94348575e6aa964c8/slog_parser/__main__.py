# Copyright 2016 Domenick Falco

import sys


from .csv import CSV

OUTPUT_TYPES = {
    'CSV': CSV,
}

def main():
    output_type = sys.argv[1]
    input_file = sys.argv[2]
    output_file = sys.argv[3]
    timestep = float(sys.argv[4])

    if(timestep <= 0):
        print('timestep must be positive')
        return

    # try:
    OutputClass = OUTPUT_TYPES[output_type]
    converter = OutputClass(input_file, output_file, timestep)

    # except KeyError:
    #     print(output_type, 'is not a known output type.')

if __name__ == '__main__':
    main()

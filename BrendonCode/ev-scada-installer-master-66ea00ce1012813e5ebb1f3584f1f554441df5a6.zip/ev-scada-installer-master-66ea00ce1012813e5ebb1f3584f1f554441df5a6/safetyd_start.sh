#! /bin/sh -
echo "Starting safetyd service..."
cd /home/scada/ev-safetyd
python3 safetyd.py &


#!/bin/bash -
X :1 &
export DISPLAY=:1
sleep 1; xset dpms force off
xset -dpms
matchbox-window-manager &
firefox localhost:1428/index.html#Dashboard-0 -private


